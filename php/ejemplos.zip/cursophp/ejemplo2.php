
<?php
error_reporting(E_ALL);

//Definiciones de variables
$a = 3;
$b = 2;
$c = ($a + ($b * 3) ) / 2;


$saludo = 'Hola Manuel, ¿cómo estas?';

$saludo2 = str_replace("Manuel","",$saludo);
echo $saludo2."<br>";
//echo "<pre>"; var_dump($saludo2); die;

$proyecto = array(
	'nombre' => 'Curso Php',
	'duracion' => '6 sesiones',
	'profesor' => 'Vicente'
);

echo "El proyecto es ". $proyecto['nombre']."<br>";

$tablero = array(
		'fila1'=>array('O','O','_'),
		'fila2'=>array('X','O','X'),
		'fila3'=>array('columna1'=>'O','columna2'=>'X','columna3'=>'X'),
	);
//echo "<pre>"; var_dump($tablero); die;
$tablero['fila4'] = array('X','_','_');

$c = 1;
$f = 3;
echo "Posición fila 3, columna 2: ".$tablero['fila'.$f]['columna'.$c];

$prueba = array('casa','coche','moto');

$prueba[] = 'boligrafo';
$prueba[] = 'lapiz';
$prueba[] = 'cuaderno';
echo "<pre>"; var_dump($prueba); die;
/* Otro comentario.
Este fichero tiene código de ejemplo.
Cuando lo utilices ten cuidado.
*/
