﻿<?php

require("./includes/ini.inc.php");
require("./includes/form.inc.php");
require("./includes/run.inc.php");

echo "Fin del código";
