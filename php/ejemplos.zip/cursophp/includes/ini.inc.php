<?php

//Inicialización

$campo1 = '';
if ( isset( $_POST['campo1'] ) ) {
	//Código si existe campo1 definido
	$campo1 = $_POST['campo1'];
}

$campo2 = '';
if ( isset($_POST['campo2']) ) {
	//Código si existe campo1 definido
	$campo2 = $_POST['campo2'];
}