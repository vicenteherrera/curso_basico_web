﻿<?php
abstract class HTMLInput extends HTMLTag implements ToBrowser, WithValue {
	public $tagName = 'input';
	protected $type;
	protected $labelText = '';
	public function setValue($newValue) {
		$this->setAtribute('value',$newValue);
	}
	public function __construct($labelText='') {
		$this->labelText = $labelText;
		parent::__construct('');
		$this->setAtribute('type', $this->type);
	}
	public function __toString() {
		$result = $this->labelText. ' ';
		$result .= parent::__toString();
		$result .= '<br>';
		return $result;
	}
}
