﻿<?php

class HTMLInputButton extends HTMLInput implements ToBrowser, WithValue {
	protected $type = 'button';
}