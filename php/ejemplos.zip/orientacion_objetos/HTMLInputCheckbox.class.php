﻿<?php

class HTMLInputCheckbox extends HTMLInput implements ToBrowser, WithValue {
	protected $type = 'checkbox';
}