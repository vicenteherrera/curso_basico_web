﻿<?php

class HTMLInputFactory {
	const TYPE_TEXT = 'text';
	const TYPE_CHECKBOX = 'checkbox';
	const TYPE_BUTTON = 'button';
	static public function create($type,$labelText='') {
		switch($type) {
			case 'button':
				$o = new HTMLInputButton();
				$o->setValue($labelText);
			break;
			case 'text':
				$o = new HTMLInputText($labelText);
			break;
			case 'checkbox':
				$o = new HTMLInputCheckbox($labelText);
			break;
			default:
				return 'Tipo no reconocido';
		}
		return $o;
	}
}