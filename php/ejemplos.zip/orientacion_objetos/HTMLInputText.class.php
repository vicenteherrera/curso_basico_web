﻿<?php

class HTMLInputText extends HTMLInput implements ToBrowser, WithValue {
	protected $type = 'text';
}