﻿<?php
class HTMLTag extends Printable implements ToBrowser  {
	public $tagName = '';
	private $atributes = array();
	public function __toString() {
		$result = '<'. $this->tagName;
		// <a href="#" target="_blank" >
		foreach($this->atributes as $key => $value) {
			$result .= ' '.$key.'="'.$value.'"';
		}
		$result .= '>';
		return $result;
	}
	public function __construct($tagName='') {
		if ( ! empty($tagName) ) {
			$this->tagName = $tagName;
		}
	}
	public function setAtribute($name, $value) {
		$this->atributes[$name] = $value;
	}
}
