﻿<?php

abstract class Printable implements ToBrowser {
	abstract function __toString();
}
