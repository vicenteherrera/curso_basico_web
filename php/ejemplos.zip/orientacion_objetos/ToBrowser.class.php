﻿<?php

interface ToBrowser {
	function __toString();
}
