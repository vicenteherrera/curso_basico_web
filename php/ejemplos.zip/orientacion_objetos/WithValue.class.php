﻿<?php

interface WithValue {
	function setValue($value);
}
