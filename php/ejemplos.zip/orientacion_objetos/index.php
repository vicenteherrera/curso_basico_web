<?php


echo "<h1>Ejemplo OO</h1>";

class EsteEsMiEjemplo1 {
	public $atrib1 = 'Hola';
	public $atrib2 = '¿cómo estás?';
	protected $atribProtegido = '';
	private $atrib3;
	private $atrib3History = array();
	public function saludo() {
		self::nombre();
		echo '<br>';
		echo $this->atrib1;
		echo $this->getAtrib3();
		echo $this->atrib2;
	}
	public function getAtrib3() {
		if ( empty($this->atrib3) ) {
			$this->atrib3 = '<br>';
		}
		return $this->atrib3;
	}
	public function setAtrib3($nuevoValor) {
		$this->atrib3History[] = $nuevoValor;
		$this->atrib3 = $nuevoValor;
	}

	static public $nombreEjemplo = 'Ejemplo1';
	static public function nombre() {
		echo self::$nombreEjemplo;
	}

}
class EsteEsMiEjemplo2 extends EsteEsMiEjemplo1 {
	public $tipo = 'Ejemplo2';
}

$a = new EsteEsMiEjemplo1();
$a->setAtrib3( ', adios' );
$a->setAtrib3('<hr>');

$b = new EsteEsMiEjemplo1();

EsteEsMiEjemplo1::$nombreEjemplo = 'Ejemplo sesión 4';

$a->saludo();

echo '<br>';
echo '<br>';
echo '<br>';

$b->saludo();


function FuncionPrueba(EsteEsMiEjemplo1 $a) {
	echo "<br>Funcion prueba:";
	$a->saludo();
}
$c = new EsteEsMiEjemplo2();
FuncionPrueba($c);

//echo Ejemplo1::$nombreEjemplo;

//Ejemplo1::nombre();