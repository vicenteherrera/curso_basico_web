﻿<?php
error_reporting(E_ALL);

function __autoload($nombre_clase) {  
    include $nombre_clase . '.class.php';  
}

$h1 = new HTMLTag('h1');
$h1_f = new HTMLTag('/h1');
echo $h1.'Ejemplo OO 2'.$h1_f.'<br>';

//$o = new HTMLInput();
$i = array();
$i[] = HTMLInputFactory::create(HTMLInputFactory::TYPE_TEXT,'Nombre');
$i[] = HTMLInputFactory::create(HTMLInputFactory::TYPE_TEXT,'Apellidos');
$i[] = HTMLInputFactory::create(HTMLInputFactory::TYPE_TEXT,'Pais');
$i[] = HTMLInputFactory::create(HTMLInputFactory::TYPE_TEXT,'Provincia');
$i[] = HTMLInputFactory::create(HTMLInputFactory::TYPE_TEXT,'Localidad');
$i[] = HTMLInputFactory::create(HTMLInputFactory::TYPE_CHECKBOX,'Acepta condiciones');
$i[] = HTMLInputFactory::create(HTMLInputFactory::TYPE_BUTTON,'Enviar');

function setClassForm(HTMLTag $input) {
	$input->setAtribute('class','myForm');
}
function setEmptyValue(WithValue $input) {
	$input->setValue('');
}

function pruebaRef( $a) {
	$a = 7;
}

foreach ($i as $input) {
	setClassForm($input);
	setEmptyValue($input);
	echo $input;
}

$b = 23;
echo "B antes: ".$b."<br>";
pruebaRef($b);
echo "B después: ".$b;


