<?php
include "fichero.php";

header("location: ../cursophp");





