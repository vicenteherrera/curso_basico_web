<?php 
	$style="color: orange;"

?>

<span style="<?=$style?>">Hola</span>
<h2 style="<?=$style?>">Hola otra vez</h2>

<?php

echo "<h1>Fechas y horas</h1>";


echo date('Y-m-d H:m:i')."<br>";

echo "July 1, 2000 is on a " . date("l", mktime(0, 0, 0, 7, 1, 2000));
echo "<br>";

setlocale(LC_ALL, 'esp');
echo strftime('%A',strtotime('+1 day')); //Día de la semana mañana
echo '<br>';

$datetime1 = date_create();
$datetime2 = date_create(strtotime('+1 day'));
var_dump($datetime1);
$interval = date_diff($datetime1, $datetime2);
echo $interval->format('%a'); //Días de diferencia

?>