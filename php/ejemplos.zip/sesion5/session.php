<?php
session_start();
echo "<h1>Ejemplo sesión</h1>";

if ( ! empty($_GET['borranombre'])) {
	unset($_SESSION['nombre']);
	echo 'Cookie borrada<br>';
}

$nombre = '';
if ( empty($_SESSION['nombre'])) {
	if ( empty($_GET['nombre'])) {
		echo '<form action="session.php" method="get">';
		echo 'Nombre: <input type="text" name="nombre" /><br>';
		echo '<input type="submit" value="enviar" /><br>';
		echo "</form>";
	} else {
		$_SESSION['nombre'] = $_GET['nombre'];
		$nombre = $_GET['nombre'];
	}
} else {
	$nombre = $_SESSION['nombre'];
}
echo "Hola ".$nombre."<br>";
if (isset($_SESSION) ) var_dump( $_SESSION );
echo "<br>";
echo '<a href="session.php?borranombre=1">Borrar sesión</a>';


