<?php

$a = 10;
$b = "10";
echo "Resultado ". ($a !== $b);