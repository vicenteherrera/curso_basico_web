<h1>Envío email</h1>
<form action="mail.php" method="post">
Desde:<br>
<input name="from"/><br>
Para:<br>
<input name="to"/><br>
Asunto<br>
<input name="subject"/><br>
Mensaje<br>
<textarea name="msg"></textarea><br>
<input type="submit" value="Enviar"/>
</form>

<?php

if ( isset($_POST['from'])) {
	$to = $_POST['to'];
	$from = $_POST['from'];
	$subject = $_POST['subject'];
	$msg = $_POST['msg'];

	$headers = '';
	$headers .= "From: $from\r\n";
    $headers .=	"Reply-To: $from\r\n";
    $headers .=	"X-Mailer: PHP/" . phpversion();

	$result = mail($to, $subject, $msg, $headers);

	if ($result) echo "Envio ok<br>";
	else echo "Error envio<br>";
}
