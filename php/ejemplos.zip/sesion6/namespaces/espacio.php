<?php

namespace PrimerEspacio;

function funcionEjemplo() {
	echo "Ejecutando funcionEjemplo() en espacio.php<br>";
}


function funcionEjemplo2() {
	Subespacio\funcionEjemplo();
}