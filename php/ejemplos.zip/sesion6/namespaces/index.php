<?php

include_once 'espacio.php';
include_once 'subespacio.php';

echo '<h1>Espacio de nombres</h1>';

function funcionEjemplo() {
	echo "Ejecutando funcionEjemplo() en index.php<br>";
}



\PrimerEspacio\funcionEjemplo2();