<?php

namespace PrimerEspacio\Subespacio;

function funcionEjemplo() {
	echo "Ejecutando funcionEjemplo() en subespacio.php<br>";
}