<?php

//Abrimos el fichero en modo 'r', lectura desde el principio
$handle = fopen("access.log", "r");
if ( ! $handle ) {
    echo "Error abriendo el fichero";
    exit;
}
$i=0;
while ( ( $line = fgets($handle) ) !== false ) {
    echo '[ Linea '.$i.']'.$line.'<br>';
    $i++;
}
fclose($handle);