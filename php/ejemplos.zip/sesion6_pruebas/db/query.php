<?php

$db = new PDO('mysql:host=localhost;dbname=cdcol;charset=utf8', 'root', '');
$db->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
$db->setAttribute(PDO::ATTR_EMULATE_PREPARES, false);

$stmt = $db->query('SELECT * FROM cds');
foreach($stmt as $row) {
    echo $row['interpret'].' '.$row['jahr'].' '.$row['titel'].'<br>';
}