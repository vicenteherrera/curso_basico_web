<form action="mail.php" method="post">
<b>Envío de email</b><br>
Desde<br><input name="from" /><br>
Hasta<br><input name="to" /><br>
Asunto<br><input name="subject" /><br>
Mensaje<br><textarea name="msg"></textarea><br>
<input type="submit" value="Enviar"/>
</form>
<?php

if ( isset($_POST['from']) ) {

	$to = $_POST['to'];
	$from = $_POST['from'];
	$subject = $_POST['subject'];
	$msg = $_POST['msg'];
	$headers = '';
	//Cabeceras para mensaje en HTML
	//$headers .= 'MIME-Version: 1.0' . "\r\n";
	//$headers .= 'Content-type: text/html; charset=iso-8859-1' . "\r\n";
	//Otras cabeceras habituales
	$headers .= 'From: '.$from . "\r\n" .
	$headers .= 'Reply-To: '.$from. "\r\n" .
	$headers .= 'X-Mailer: PHP/' . phpversion();
	$result = mail($to, $subject, $msg, $headers);
	echo "<br>Envío de email intentado con resultado ";
	if ($result) echo "correcto"; else echo "incorrecto";
}