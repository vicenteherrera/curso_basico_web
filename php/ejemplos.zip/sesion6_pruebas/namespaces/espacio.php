<?php
/* fichero: espacio.php */
namespace EjemploCurso;

include_once 'subespacio.php';

function funcionEjemplo() {
    echo 'EjemploCurso : funcionEjemplo<br>';
	
	// llamadas equivalentes en el mismo espacio
	otraFuncionEjemplo();
	\EjemploCurso\otraFuncionEjemplo();
	
	// llamadas equivalentes a un subespacio
	Subespacio\otraFuncionEjemplo();
	\EjemploCurso\Subespacio\otraFuncionEjemplo();
	
	// llamada a espacio de nombres ra�z
	\otraFuncionEjemplo();
}
function otraFuncionEjemplo() {
	echo 'EjemploCurso : otraFuncionEjemplo<br>';
}