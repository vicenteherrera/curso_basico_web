<?php
/* fichero: inicio.php */
function funcionRaiz() {
    echo 'funcionRaiz<br>';
	
	// llamada a funcion dentro del mismo espacio ra�z
	otraFuncionEjemplo();
	
	// llamadas equivalentes a otro espacio de nombres
	EjemploCurso\funcionEjemplo();
	\EjemploCurso\funcionEjemplo();
	
	// llamadas equivalentes a un subespacio de nombres
	EjemploCurso\Subespacio\functionSubespacio();
	\EjemploCurso\Subespacio\functionSubespacio();
}
function otraFuncionEjemplo() {
	echo 'otraFuncionEjemplo<br>';
}
include_once 'espacio.php';
include_once 'subespacio.php';

funcionRaiz();