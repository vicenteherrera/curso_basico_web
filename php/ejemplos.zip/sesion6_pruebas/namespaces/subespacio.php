<?php
/* fichero: subespacio.php */
namespace EjemploCurso\Subespacio;

function functionSubespacio() {
    echo 'EjemploCurso\Subespacio : funcionSubespacio<br>';
	
	// llamadas equivalentes dentro del mismo subespacio
	\EjemploCurso\Subespacio\otraFuncionEjemplo();
	otraFuncionEjemplo();
	
	// llamada a espacio de nombres ra�z
	\otraFuncionEjemplo();
}
function otraFuncionEjemplo() {
	echo 'EjemploCurso\Subespacio : otraFuncionEjemplo<br>';
}