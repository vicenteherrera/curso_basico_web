
//Retirar clase CSS
$(el).removeClass(className);

//Ocultar elemento/s
$(el).hide();

//Mostrar elemto/s
$(el).show();

//Ejecuta una función sobre cada elemento
$(selector).each(function(i, el){
    //...
});

//Coincide con selector
$(el).is('.my-class');

//Obtener coordenadas
$(el).offset();

//Establecer estilo
$(el).css('border-width', '20px');

//Añadir evento Off
$(el).off(eventName, eventHandler);

//Añadir evento On
$(el).on(eventName, eventHandler);

//Ejecutar cuando el documento HTML esté preparado
$(document).ready(function(){
    //...
});